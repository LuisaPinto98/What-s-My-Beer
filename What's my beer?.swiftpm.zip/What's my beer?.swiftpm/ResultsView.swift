//
//  QuizView.swift
//  What's my beer?
//
//  Created by Luisa Pinto on 14/04/22.
//

import SwiftUI

struct ResultsView: View {
    
    @State var beers : [BeerData] = []
   
    @State var beersSorted : [BeerData] = []
    
    @Binding var isShowingQuizView: Bool
    
    func moveTo(){
        isShowingQuizView.toggle()
    }
    
    var body: some View {
        
        VStack{
                
                Image("little_logo")
                    .imageScale(.small)
                    .padding(.top, 50.0)   .onAppear(perform: {
                        beers.removeAll()
                        beersSorted.removeAll()
                        beers=load()
                        
                    
                   // beers = load()
                        for beer in beers {
                            print(type)
                            if(beer.tags_food.contains(arrayTag) && type=="Food 🍽"){
                               
                                beersSorted.append(beer)
                            }else if(beer.tags_taste.contains(arrayTag) && type=="Beer 🍺"){
                                beersSorted.append(beer)
                            }
                        }
                    })
            
            Text("Results")
                .padding(.all, (UIScreen.main.bounds.height)/22)
                .controlSize(.large)
                .font(.system(size: 32, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .shadow(color: Color(red: 130/255, green: 130/255, blue: 130/255, opacity: 50), radius: 5, x: 3, y: 3)
                
            
        
        
            
            ScrollView {
                VStack (spacing: 20) {
            
                    if (beersSorted.isEmpty) {
                        Image ("NoResults_Card")
                        }else{
                            ForEach(beersSorted) { beer in
                    Image("\(beer.beer_card)")
                        }
           
                        
            
            }
                }
            }.frame(height: (UIScreen.main.bounds.height)/2)
            
            Spacer()
            
                
                Button("Done"){
                    
                   
                    arrayTag=""
                    isShowingQuizView = false
                    
                    

                }
                .padding(.all, 20.0)
                .controlSize(.large)
                .font(.system(size: 32, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .background(Color(red: 54/255, green: 169/255, blue: 224/255, opacity: 100))
                .cornerRadius(20)
                .shadow(color: Color(red: 130/255, green: 130/255, blue: 130/255, opacity: 50), radius: 5, x: 3, y: 3)
                .shadow(color: Color(red: 200/255, green: 200/255, blue: 200/255, opacity: 50), radius: 5, x: -3, y: -3)
                
           
            Spacer()
            Spacer()
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
        
            .background(LinearGradient(gradient: Gradient(colors: [Color(red: 248/255, green: 204/255, blue: 124/255, opacity: 100), Color(red: 249/255, green: 178/255, blue: 51/255, opacity: 100)]), startPoint: .top, endPoint: .bottom))
        
            .preferredColorScheme(.light)
            .navigationBarHidden(true)
        
     
        
}
}

