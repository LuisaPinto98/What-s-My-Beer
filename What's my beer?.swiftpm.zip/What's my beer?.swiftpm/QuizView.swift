//
//  QuizView.swift
//  What's my beer?
//
//  Created by Luisa Pinto on 19/04/22.
//

import SwiftUI

struct QuizView: View {

    @Binding var isShowingQuizView: Bool

    init(isShowingQuizView: Binding<Bool>){
            UINavigationBar.setAnimationsEnabled(false)
        self._isShowingQuizView = isShowingQuizView
        }
    
    
    var body: some View {
        NavigationView {
            QuizPageView(isShowingQuizView: $isShowingQuizView, story: story, pageIndex: 0)
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
        
        .navigationViewStyle(.stack)
        .preferredColorScheme(.light)
        .navigationBarHidden(true)
        
        
    }
}


