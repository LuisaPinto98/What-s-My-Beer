import Foundation
import SwiftUI


struct MainView: View {
    
    @State var loopMovingSx = false
    @State var loopMovingDx = false
    @State var tapMoving = false
    @State var isShowingQuizView = false
    
    private let animation1 = Animation.linear(duration: 5.0).repeatForever(autoreverses: true)
    
    private let animation2 = Animation.linear(duration: 1.0).delay(3)
    
   
    
    @State private var offset = 1.0
    
    @State var isShowing = true
    
    @State var scalino = 0
    @State var opacità = 0.0
    
    func moveTo(){
        isShowingQuizView = true
    }
    
    func bottoncino() {
        
        if isShowing == true {
            scalino = 1
            opacità = 1.0
        } else {
            scalino = 0
            opacità = 0.0
        }
    }
    
    
    
    var body: some View {
        
        
      
        ZStack {
            
            HStack{
                
                VStack{
                    
                Image("hopsLoop")
              .rotationEffect(.degrees(180))
             .imageScale(.small)
             .offset(y: loopMovingSx ? 100 : -100)
             .onAppear {
                 withAnimation(self.animation1, {
                 self.loopMovingSx.toggle()
             })
         }
                    
                    
                }.ignoresSafeArea()
                
                Spacer()
                
            VStack{
                
                Image("hopsLoop")
                .imageScale(.small)
                .offset(y: loopMovingDx ? -100 : 100)
                .animation(
                    .linear(duration: 4.0)
                        .repeatForever(autoreverses: true),
                    value: offset)
                .onAppear {
                    withAnimation(self.animation1, {
                    self.loopMovingDx.toggle()
                })
            }
                
                
            }.ignoresSafeArea()
                
            }.ignoresSafeArea()
            
            ZStack{
                
                VStack {
            
           
            Spacer()
            Spacer()
            
            
            Image("logo")
                .imageScale(.small)
                .padding(.top, (UIScreen.main.bounds.height)/50)
            
            
                    
            Text("Ready for a bunch of questions\nto find your soulmate beer?\nLet’s figure it out! ")
                .multilineTextAlignment(.center)
                .font(.system(size: 24, design: .rounded))
                .padding()
               
                 
            Button("Start the test"){
                withAnimation {
                moveTo()
                }
            }
            .padding(.all, 20.0)
            .controlSize(.large)
            .font(.system(size: 32, weight: .bold, design: .rounded))
            .foregroundColor(.white)
            .background(Color(red: 54/255, green: 169/255, blue: 224/255, opacity: 100))
            .cornerRadius(20)
            .shadow(color: Color(red: 130/255, green: 130/255, blue: 130/255, opacity: 50), radius: 5, x: 3, y: 3)
            .shadow(color: Color(red: 200/255, green: 200/255, blue: 200/255, opacity: 50), radius: 5, x: -3, y: -3)
            
            .padding(.bottom, 80.0)
                    
                  
                        .padding((UIScreen.main.bounds.height)/40)
                 
            ZStack{
                Image("tapMe")
                    .padding(.top, 120.0)
                
              .offset(x: tapMoving ? 120 : 0)
              .onAppear {
                withAnimation(self.animation2, {
                 self.tapMoving.toggle()
                    })
                }
                
            Image("lulla")
                .padding(.top, -40.0)
                .imageScale(.small)
            
                .onTapGesture {
                    withAnimation{
                        isShowing.toggle()
                        bottoncino()}
                    
                   
                }
            
            }
                
            
            Spacer()
                
            
            
        }
                Image("aboutMe")
               
                    .padding(.bottom, 240)
                    .scaleEffect(x: CGFloat(scalino), y: CGFloat(scalino), anchor: .center)
                    .opacity(opacità)
                
                    
                
        }
            if isShowingQuizView{
                QuizView(isShowingQuizView: $isShowingQuizView)
            }
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
        
            .background(LinearGradient(gradient: Gradient(colors: [Color(red: 248/255, green: 204/255, blue: 124/255, opacity: 100), Color(red: 249/255, green: 178/255, blue: 51/255, opacity: 100)]), startPoint: .top, endPoint: .bottom))
            .onTapGesture {
                withAnimation{
                isShowing = false
                bottoncino()
                }}
            .preferredColorScheme(.light)
        

            
          
       
    
    }
}


