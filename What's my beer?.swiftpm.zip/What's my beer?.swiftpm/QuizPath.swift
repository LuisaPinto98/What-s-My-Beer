//
//  QuizPath.swift
//  What's my beer?
//
//  Created by Luisa Pinto on 19/04/22.
//

import Foundation
import SwiftUI

let story = Story(pages: [
    StoryPage( // 0
        """
        Are you searching for a pairing with food\nor just a beer suitable for your taste?
        """,
        choices: [
            Choice(text: "Food 🍽", destination: 1),
            Choice(text: "Beer 🍺", destination: 14),
        ]
    ),
    StoryPage( // 1
        """
        With which kind of food are you\nsearching for a beer-pairing?
        """,
        choices: [
            Choice(text: "Red Meats", destination: 2),
            Choice(text: "White Meats", destination: 4),
            Choice(text: "Fish", destination: 5),
            Choice(text: "Eggs", destination: 6),
            Choice(text: "Cheese", destination: 7),
            Choice(text: "Cured Meats", destination: 8),
            Choice(text: "Shellfish", destination: 9),
            Choice(text: "Vegetables", destination: 10),
            Choice(text: "Risotto", destination: 11),
            Choice(text: "Pizza", destination: 12),
            Choice(text: "Desserts", destination: 13),
        ]
    ),
    StoryPage( // 2
        """
        Juicy!\nWhich kind of Red Meat in particular?
        """,
        choices: [
            Choice(text: "Beef", destination: 3),
            Choice(text: "Veal", destination: 3),
            Choice(text: "Mutton", destination: 3),
            Choice(text: "Venison", destination: 3),
            Choice(text: "Lamb", destination: 3),
            Choice(text: "Pork", destination: 3),
        ]
    ),
    StoryPage( // 3
        """
        Great choice!\nNow, cooked with which method?
        """,
        choices: [
            Choice(text: "Streamed", destination: 21),
            Choice(text: "Raw", destination: 21),
            Choice(text: "Fried", destination: 21),
            Choice(text: "Grilled", destination: 21),
            Choice(text: "Stewed", destination: 21),
            Choice(text: "Stir-fried", destination: 21),
            Choice(text: "Au Gratin", destination: 21),
        ]
    ),
    StoryPage( // 4
        """
        Juicy!\nWhich kind of White Meat in particular?
        """,
        choices: [
             Choice(text: "Chicken", destination: 3),
             Choice(text: "Rabbit", destination: 3),
             Choice(text: "Turkey", destination: 3),
             Choice(text: "Duck", destination: 3),
        ]
    ),
    StoryPage( // 5
        """
        Juicy!\nWhich kind of Fish in particular?
        """,
        choices: [
                    Choice(text: "Sea Bass", destination: 3),
                    Choice(text: "Sea Bream", destination: 3),
                    Choice(text: "Tuna", destination: 3),
                    Choice(text: "Salmon", destination: 3),
                    Choice(text: "Cod Fish", destination: 3),
                    Choice(text: "Sword Fish", destination: 3),
                    Choice(text: "Anchovy", destination: 3),
        ]
    ),
    StoryPage( // 6
        """
        Tasty!\nWhich kind of cooked eggs in particular?
        """,
        choices: [
                    Choice(text: "Hard-Boiled", destination: 21),
                    Choice(text: "Omelette", destination: 21),
                    Choice(text: "Quiche", destination: 21),
                    Choice(text: "Deviled", destination: 21),
        
       
        ]
    ),
    StoryPage( // 7
        """
        Juicy!\nWhich kind of cheese in particular?
        """,
        choices: [
                    Choice(text: "Soft Paste", destination: 21),
                    Choice(text: "Aged", destination: 21),
                    Choice(text: "Goat or Sheep", destination: 21),
                    Choice(text: "Gorgonzola", destination: 21),
                    Choice(text: "Hard Marbled", destination: 21),
        ]
    ),
    StoryPage( // 8
        """
        Tasty!\nWhich kind of cured meats in particular?
        """,
        choices: [
                    Choice(text: "Fatty", destination: 21),
                    Choice(text: "Light", destination: 21),
                    Choice(text: "Seasoned", destination: 21),
        ]
    ),
    StoryPage( // 9
        """
        Tasty!\nWhich kind of shellfish in particular?
        """,
         choices: [
                    Choice(text: "Mussels", destination: 3),
                    Choice(text: "Oysters", destination: 3),
                    Choice(text: "Crabs", destination: 3),
                    Choice(text: "Lobsters", destination: 3),
                    Choice(text: "Prawns", destination: 3),
                    Choice(text: "Octopus", destination: 3),
                    Choice(text: "Squid", destination: 3),
        
        ]
    ),
    StoryPage( // 10
        """
        Tasty!\nWhich kind of vegetables in particular?
        """,
        choices: [
                    Choice(text: "Green Leaves", destination: 3),
                    Choice(text: "Zuchini", destination: 3),
                    Choice(text: "Bell Peppers", destination: 3),
                    Choice(text: "Tomatoes", destination: 3),
                    Choice(text: "Potatoes", destination: 3),
                    Choice(text: "Eggplant", destination: 3),
        ]
    ),
    StoryPage( // 11
        """
        Tasty!\nWhich kind of risotto in particular?
        """,
         choices: [
                    Choice(text: "With Cheese", destination: 21),
                    Choice(text: "With Leeks", destination: 21),
                    Choice(text: "With Porcini", destination: 21),
                    Choice(text: "With Saffron", destination: 21),
                    Choice(text: "With Vegetables", destination: 21),
                    Choice(text: "With Meat", destination: 21),
        ]
    ),
    StoryPage( // 12
        """
        Tasty!\nWhich kind of pizza in particular?
        """,
         choices: [
                   Choice(text: "Margherita", destination: 21),
                   Choice(text: "Origano and Garlic", destination: 21),
                   Choice(text: "With Cheese", destination: 21),
                   Choice(text: "With Meat", destination: 21),
                   Choice(text: "With Vegetables", destination: 21),
                   Choice(text: "Stuffed with Ricotta", destination: 21),
        ]
    ),
    StoryPage( // 13
        """
        Tasty!\nWhich kind of dessert in particular?
        """,
        choices: [
                    Choice(text: "Pies", destination: 21),
                    Choice(text: "Chocolate Bars", destination: 21),
                    Choice(text: "Cooked Fruits", destination: 21),
                    Choice(text: "Dried Fruits", destination: 21),
                    Choice(text: "Fruits Salad", destination: 21),
                    Choice(text: "Sweet Pastries", destination: 21),
                    Choice(text: "Cheesecakes", destination: 21),
                    Choice(text: "Tiramisù", destination: 21),
                    Choice(text: "Cinnamon Rolls", destination: 21),
                 
                 ]
    ),
    StoryPage( // 14
        """
        How much alcoholic do you prefer it?
        """,
        choices: [
            Choice(text: "Slightly Alcoholic", destination: 15),
            Choice(text: "Medium Alcoholic", destination: 15),
            Choice(text: "Highly Alcoholic", destination: 15),
        ]
    ),
    StoryPage( // 15
        """
        How much carbonated do you prefer it?
        """,
        choices: [
            Choice(text: "Slightly Carbonated", destination: 16),
            Choice(text: "Medium Carbonated", destination: 16),
            Choice(text: "Highly Carbonated", destination: 16),
        ]
    ),
    StoryPage( // 16
        """
        How much hoppy do you prefer it?
        """,
        choices: [
            Choice(text: "Slightly Hoppy", destination: 17),
            Choice(text: "Medium Hoppy", destination: 17),
            Choice(text: "Highly Hoppy", destination: 17),
        ]
    ),
    StoryPage( // 17
        """
        How much bitter do you prefer it?
        """,
        choices: [
            Choice(text: "Slightly Bitter", destination: 18),
            Choice(text: "Medium Bitter", destination: 18),
            Choice(text: "Highly Bitter", destination: 18),
        ]
        
    ),
    StoryPage( // 18
        """
        How much dry do you prefer it?
        """,
        choices: [
            Choice(text: "Slightly Dry", destination: 19),
            Choice(text: "Medium Dry", destination: 19),
            Choice(text: "Highly Dry", destination: 19),
        ]
    ),
    StoryPage( // 19
        """
        Which body do you prefer?
        """,
        choices: [
            Choice(text: "Light Body", destination: 21),
            Choice(text: "Medium Body", destination: 21),
            Choice(text: "Full Body", destination: 21),
                ]
    ),
    
])
