//
//  QuizPageView.swift
//  What's my beer?
//
//  Created by Luisa Pinto on 19/04/22.
//

import SwiftUI

let columns = [GridItem(.fixed(250)),
               GridItem(.fixed(250))]

var arrayTag: String = ""
var type:String = ""

struct QuizPageView: View {
  
    @Binding var isShowingQuizView: Bool

            let story: Story
            let pageIndex: Int

            var body: some View {
                
                VStack {
                    
                        Image("little_logo")
                            .imageScale(.small)
                            .padding(.top, 50.0)
                    
                          
                Spacer()
                 
                    
                    Text(story[pageIndex].text)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .font(.system(size: UIScreen.main.bounds.width/25, design: .rounded))
                    
                    Spacer()
                    
                    VStack{
                    LazyVGrid(columns: columns){
                        
                    ForEach(story[pageIndex].choices, id: \Choice.text) { choice in
                        if(choice.destination != 21){
                            
                            NavigationLink(destination: QuizPageView(isShowingQuizView: $isShowingQuizView, story: story, pageIndex: choice.destination).onAppear(perform: {
                                if(!(choice.text=="Food 🍽") && !(choice.text=="Beer 🍺")){
                                    
                                    arrayTag.append("\(choice.text)_")
                                    print(arrayTag)
                                }else{
                                    arrayTag.removeAll()
                                    type=choice.text
                                }
                            })) {
                                
                                
                                Text(choice.text)
                                    .fontWeight(.bold)
                                    .font(.system(size: UIScreen.main.bounds.width/30, design: .rounded))
                                    .multilineTextAlignment(.center)
                                    .padding(.all, 20.0)
                                    .foregroundColor(.white)
                                    .background(Color(red: 54/255, green: 169/255, blue: 224/255, opacity: 100))
                                    .cornerRadius(20)
                                 }
                                 .padding(.all, 8.0)
                        }else{
                            NavigationLink(destination: ResultsView( isShowingQuizView: $isShowingQuizView).onAppear(perform: {
                                if(!(choice.text=="Food 🍽") && !(choice.text=="Beer 🍺")){
                                    
                                    arrayTag.append("\(choice.text)_")
                                    print(arrayTag)
                                }else{
                                    type=choice.text
                                    arrayTag.removeAll()
                                    
                                }
                            })) {
                                
                                Text(choice.text)
                                    .fontWeight(.bold)
                                    .font(.system(size: UIScreen.main.bounds.width/30, design: .rounded))
                                    .multilineTextAlignment(.center)
                                    .padding(.all, 20.0)
                                    .foregroundColor(.white)
                                    .background(Color(red: 54/255, green: 169/255, blue: 224/255, opacity: 100))
                                    .cornerRadius(20)
                                 }
                                 .padding(.all, 8.0)
                                 .navigationBarHidden(true)
                        }
                      
                        
                    }
                }
                    }
                    
                    Spacer()
                    Spacer()
                }
                .padding(.bottom)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
                
                    .background(LinearGradient(gradient: Gradient(colors: [Color(red: 248/255, green: 204/255, blue: 124/255, opacity: 100), Color(red: 249/255, green: 178/255, blue: 51/255, opacity: 100)]), startPoint: .top, endPoint: .bottom))
                
                    .preferredColorScheme(.light)
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarHidden(true)
            }
        }

        

