//
//  File.swift
//  What's my beer?
//
//  Created by Luisa Pinto on 14/04/22.
//

import Foundation


class BeerData : Identifiable, Codable {
    
    var id : Int
    var beer_name : String
    var beer_card : String
    var tags_taste : [String]
    var tags_food : [String]
    
}

var beers: [BeerData] = load()

func load<T: Decodable>() -> T {

    let data: Data

    guard let file = Bundle.main.url(forResource: "stylesdata", withExtension: "json")
        else {
            fatalError("Couldn't find in main bundle.")

    }
print("1")
    do {
        data = try Data(contentsOf: file)
        print("2")

    } catch {
        fatalError("Couldn't load from main bundle:\n\(error)")
    }
    print("3")

    do {
        let decoder = JSONDecoder()
        print("4")

        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Couldn't parse as \(T.self):\n\(error)")
    }
}

